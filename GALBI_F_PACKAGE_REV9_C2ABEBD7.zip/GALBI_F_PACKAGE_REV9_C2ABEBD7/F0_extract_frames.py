# F0_extract_frames.py — Flow V1 mp4에서 프레임을 뽑고 '입 영역 선명도'로 상위 후보를 고른다. (비용 0, 원본 보존)
# 사용: python3 F0_extract_frames.py <FLOW_V1.mp4> <출력폴더>
# 필요: ffmpeg, python3 + Pillow + numpy (없으면 `python3 -m pip install pillow numpy`)
import sys, os, subprocess, json
from PIL import Image, ImageFilter
import numpy as np

src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
frames_dir = os.path.join(out, "frames"); os.makedirs(frames_dir, exist_ok=True)
# 1) 전 프레임 PNG 추출 (720p 원본 그대로, 재인코딩 없음)
subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", src, os.path.join(frames_dir, "f%04d.png")], check=True)
files = sorted(f for f in os.listdir(frames_dir) if f.endswith(".png"))
print("추출 프레임 수:", len(files))

# 2) 선명도 점수: 중앙 영역(입·혀가 있는 곳) 라플라시안 분산. 영역은 필요하면 ROI 를 바꾼다.
def sharpness(path):
    im = Image.open(path).convert("L")
    w, h = im.size
    roi = im.crop((int(w*0.25), int(h*0.25), int(w*0.75), int(h*0.85)))   # 중앙 아래쪽
    lap = roi.filter(ImageFilter.Kernel((3, 3), [0, 1, 0, 1, -4, 1, 0, 1, 0], scale=1))
    return float(np.asarray(lap, dtype=np.float32).var())

scores = [(sharpness(os.path.join(frames_dir, f)), f) for f in files]
scores.sort(reverse=True)
top = scores[:8]
json.dump([{"frame": f, "sharpness": round(s, 1)} for s, f in top], open(os.path.join(out, "F0_top_frames.json"), "w"), indent=1)

# 3) 상위 8장을 한 장의 비교표(2x4)로
thumbs = [Image.open(os.path.join(frames_dir, f)).convert("RGB") for _, f in top]
tw, th = thumbs[0].size; tw, th = tw // 2, th // 2
sheet = Image.new("RGB", (tw * 4, th * 2), (20, 20, 20))
for i, im in enumerate(thumbs):
    sheet.paste(im.resize((tw, th)), ((i % 4) * tw, (i // 4) * th))
sheet.save(os.path.join(out, "F0_contact_sheet.png"))
for s, f in top: print(f"{f}  선명도 {s:.1f}")
print("\n[중단 F-0] F0_contact_sheet.png 와 위 목록을 보고, 혀끝·앞니·입술이 가장 또렷한 프레임 1장을 고른다. 고른 파일명을 보고.")
