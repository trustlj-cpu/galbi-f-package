# Codex 실행 지침 — GALBI 첫 최소 실험 F (비용 0)

작성: Claude Code (Claude Fable 5.1) · 2026-10-05
Source of Truth: **이 ZIP(GALBI_F_PACKAGE_REV9_C2ABEBD7.zip) 내부 파일**. 패키지 라벨 revision 9 / c2abebd7 (`PACKAGE_VERSION.txt`), 파일 무결성은 `MANIFEST_SHA256.txt`로 검증한다. Gist·URL·외부 네트워크는 실행 전제조건이 아니다. 이 지침은 §10 [첫 최소 실험] F를 **Codex가 로컬에서 그대로 실행**할 수 있게 쓴 것이다. 범위를 넓히지 않는다.

역할: Claude = 설계·판단·검토. **Codex = 로컬 파일 생성·스크립트 실행·Blender 실행·QA.** 사용자 = GUI가 꼭 필요할 때만 개입 + 각 STOP 승인.

---

## 0. Codex 절대 규칙 (하나라도 어기면 중단)

1. **비용 0.** Flow·Nano Banana·GPT Image·기타 유료 생성·클라우드·자산 구매 호출 금지.
2. UE / MetaHuman 실행·재개 금지. `/Applications/Epic Games`, UE 프로젝트 폴더는 열지 않는다.
3. 기존 Blender 머리/구강 메시(`05_3D_ARTICULATORY_RIG`, `06_MOTION_REFERENCE`의 .blend 안 지오메트리)를 **어떤 출력에도 쓰지 않는다**. 이번 실험은 그 파일을 열지도 않는다.
4. 기존 마스터·FLOW_TESTS 원본은 **read-only**. 복사하지 않고 경로로 읽기만. 쓰기는 `09_F_EXPERIMENT/` 아래에만.
5. GUI 자동 조작(클릭·키 입력) 금지. 모든 작업은 터미널 명령과 스크립트로. Blender는 `-b`(백그라운드)로만 실행.
6. 메모리 압력: 각 단계 시작 전·후 `memory_pressure | tail -1`로 확인. **여유 메모리 30% 미만(노랑 이상)이면 즉시 STOP**하고 보고. (Activity Monitor 색의 근사치. 사용자가 Activity Monitor를 보고 있으면 그 색이 우선.)
7. 각 STOP 지점에서 **보고하고 멈춘다.** 사용자 승인 메시지 없이는 다음 단계 명령을 실행하지 않는다.
8. 한 단계 실패 시 **같은 방식의 수정은 1회만**(one-adjustment). 두 번째 실패는 "FALLBACK A 제안"으로 보고.
9. 하지 않은 일을 했다고 쓰지 않는다. 출력 파일이 실제로 존재하는지 `ls -l`로 확인한 뒤 보고.

---

## 1. 입력 파일/폴더 (정확한 경로)

프로젝트 루트 `ROOT = $HOME/Documents/Codex/KOREAN_PRONUNCIATION_SHORTS` (인수인계 문서 4절 기준. 다르면 사용자에게 확인하고 STOP).

| 용도 | 경로 | 권한 |
|---|---|---|
| 기준 영상 | `$ROOT/FLOW_TESTS/GALBI_NEUTRAL_CUTAWAY_V1/FLOW_GALBI_NEUTRAL_CUTAWAY_V1_720p.mp4` | 읽기만 |
| 실행 패키지 | 사용자가 둔 `GALBI_F_PACKAGE_REV9_C2ABEBD7.zip` (내용: `CODEX_F_INSTRUCTIONS.md`, `F_RUNBOOK.md`, `F0_extract_frames.py`, `F1_trace_and_cut.py`, `F2_blender_min25d.py`, `PACKAGE_VERSION.txt`, `MANIFEST_SHA256.txt`) | 압축 해제 후 SHA-256 검증 |

이번 실험은 **랜드마크 JSON·기존 모션 .blend를 쓰지 않는다**(혀끝·치조 위치는 고른 프레임에서 픽셀로 직접 지정).

## 2. 생성할 출력 파일/폴더

```
$ROOT/GALBI_PILOT/09_F_EXPERIMENT/
  F0_extract_frames.py  F1_trace_and_cut.py  F2_blender_min25d.py  F_RUNBOOK.md
  F_out/
    frames/f0001.png …            (F-0, 전 프레임)
    F0_top_frames.json            (F-0, 선명도 상위 8)
    F0_contact_sheet.png          (F-0, 2×4 비교표)
    F1_trace.json                 (F-1, 혀 다각형 + tip/alveolar/root 픽셀)
    F1_overlay.png                (F-1, 검토용 오버레이)
    L_tongue.png  L_cavity.png  L_rest.png  F1_layers_sheet.png   (F-1)
    F2_scene.blend                (F-2)
    render/F2_neutral.png  render/F2_contact.png  render/pingpong_0000~0009.png  (F-2)
    F2_log.txt                    (F-2, Blender 표준출력 — "혀끝→치조 거리 N px" 포함)
  REPORT_F0.md  REPORT_F1.md  REPORT_F2.md   (각 STOP 보고 사본)
```

## 3. 실행 순서 (명령을 그대로)

### 3-0 준비
```bash
ROOT="$HOME/Documents/Codex/KOREAN_PRONUNCIATION_SHORTS"
test -f "$ROOT/FLOW_TESTS/GALBI_NEUTRAL_CUTAWAY_V1/FLOW_GALBI_NEUTRAL_CUTAWAY_V1_720p.mp4" || { echo "기준 영상 없음 — STOP"; exit 1; }
mkdir -p "$ROOT/GALBI_PILOT/09_F_EXPERIMENT" && cd "$ROOT/GALBI_PILOT/09_F_EXPERIMENT"
# ZIP 은 사용자가 이 Mac 에 둔 경로를 쓴다 (예: ~/Downloads). 네트워크로 받지 않는다.
ZIP="$HOME/Downloads/GALBI_F_PACKAGE_REV9_C2ABEBD7.zip"; test -f "$ZIP" || { echo "ZIP 없음 — 사용자에게 경로 확인 후 STOP"; exit 1; }
unzip -o -q "$ZIP" -d . && cat PACKAGE_VERSION.txt
shasum -a 256 -c MANIFEST_SHA256.txt || { echo "SHA-256 불일치 — STOP (패키지 손상)"; exit 1; }
python3 -c "import PIL, numpy; print('py ok')" || python3 -m pip install --user pillow numpy
which ffmpeg || brew list ffmpeg >/dev/null 2>&1 || echo "ffmpeg 없음 — 사용자에게 설치 요청 후 STOP (brew install ffmpeg)"
BLENDER="$(which blender || echo /Applications/Blender.app/Contents/MacOS/Blender)"; "$BLENDER" --version | head -1 || { echo "Blender 없음 — STOP"; exit 1; }
memory_pressure | tail -1
```
(F-1을 클릭 없이 하므로 matplotlib은 필요 없음. 사용자가 직접 클릭하길 원할 때만 `pip install matplotlib`.)

### 3-1 F-0 프레임 추출 (프레임 추출 규칙 → §5)
```bash
python3 F0_extract_frames.py "$ROOT/FLOW_TESTS/GALBI_NEUTRAL_CUTAWAY_V1/FLOW_GALBI_NEUTRAL_CUTAWAY_V1_720p.mp4" F_out
ls -l F_out/F0_contact_sheet.png F_out/F0_top_frames.json; cat F_out/F0_top_frames.json; memory_pressure | tail -1
```
Codex는 `F0_contact_sheet.png`를 **이미지로 열어 보고**(파일 뷰), 상위 8장 중 §5 기준으로 1장을 **추천**한다(최종 선택은 사용자).
**→ STOP F-0. §10 형식으로 보고. 사용자가 프레임을 확정하면 3-2.**

### 3-2 F-1 레이어 분리 (규칙 → §6)
클릭 없이: Codex가 고른 프레임 `F_out/frames/<fXXXX>.png`를 이미지로 열어 혀 윤곽 다각형(시계 방향 16~30점)과 3점(혀끝·치조·혀뿌리)의 **픽셀 좌표를 직접 작성**해 `F_out/F1_trace.json`에 저장한다. 형식:
```json
{"frame":"f0123.png","size":[1280,720],
 "tongue_polygon":[[x,y],[x,y],...],
 "tip_px":[x,y],"alveolar_px":[x,y],"root_px":[x,y]}
```
그 다음:
```bash
python3 F1_trace_and_cut.py overlay F_out/frames/<fXXXX>.png F_out      # F1_overlay.png 생성 → 이미지로 열어 윤곽이 혀 가장자리와 맞는지 자체 검토
# 어긋나면 F1_trace.json 좌표를 고치고 overlay 를 다시(이건 수정 횟수에 안 셈 — 아직 cut 전)
python3 F1_trace_and_cut.py cut F_out/frames/<fXXXX>.png F_out
ls -l F_out/L_tongue.png F_out/L_cavity.png F_out/L_rest.png F_out/F1_layers_sheet.png; memory_pressure | tail -1
```
(사용자가 직접 클릭하고 싶다면 대신 `python3 F1_trace_and_cut.py trace …` — 이때만 GUI 개입.)
**→ STOP F-1. 보고. 사용자 승인 후 3-3.**

### 3-3 F-2 Blender 2.5D 최소 구성 + 렌더 (규칙 → §7)
```bash
memory_pressure | tail -1
"$BLENDER" -b -P F2_blender_min25d.py -- "$PWD/F_out" 2>&1 | tee F_out/F2_log.txt
grep "혀끝→치조 거리" F_out/F2_log.txt
ls -l F_out/render/F2_neutral.png F_out/render/F2_contact.png F_out/render/pingpong_0009.png F_out/F2_scene.blend
ffmpeg -loglevel error -y -framerate 10 -i F_out/render/pingpong_%04d.png -c:v libx264 -pix_fmt yuv420p F_out/render/F2_pingpong.mp4
memory_pressure | tail -1
```
Codex는 `F2_neutral.png`·`F2_contact.png`를 이미지로 열어 §9의 (b)(c)만 **기계적으로** 확인한다. (a) 자연스러움 판정은 **사용자**가 한다.
**→ STOP F-2 (최종). 보고. PASS여도 여기서 멈춘다. C1(유료)은 별도 승인.**

## 4. 필요한 Blender/Python 작업 요약

- Python 3 (Pillow, numpy): 프레임 선명도 점수, 다각형 마스크로 혀 레이어 알파 추출, 혀 자리를 어두운 구강색으로 메운 배경판 생성, 비교표.
- Blender 4.x `-b` 모드 스크립트: 평면 2장(배경판·혀) 생성, 혀 평면 61×61 세분, 혀끝→치조 변위를 뿌리 쪽으로 감쇠시키는 셰이프키 `L_contact` 자동 생성, 직교 카메라, 이미시브 머티리얼(그림 그대로 보이게), 정지 2장 + 10프레임 왕복 PNG 렌더, `.blend` 저장, 혀끝→치조 거리(px) 출력.
- Blender GUI는 열지 않는다. 사용자가 보고 싶으면 `F2_scene.blend`를 직접 연다.

## 5. 프레임 추출 규칙

- ffmpeg로 **전 프레임** PNG, 재인코딩·리사이즈 없음(720p 그대로).
- 선명도 = 중앙 아래 ROI(가로 25~75%, 세로 25~85%)의 라플라시안 분산. 상위 8장을 비교표로.
- Codex 추천 기준(우선순위): ① 혀끝·윗앞니·입술 윤곽이 또렷 ② 입이 **살짝 벌어져** 혀와 입천장 사이가 보임(완전히 닫힌 프레임 제외) ③ 모션 블러·압축 뭉개짐 없음 ④ 자막·UI 없음.
- 최종 선택은 사용자. Codex는 "추천 1장 + 이유 한 줄"만.

## 6. 레이어 분리 규칙

- 혀 다각형: 혀끝부터 시계 방향, 16~30점, 혀 아랫면이 구강저와 만나는 선까지 포함. 입술·이는 **포함하지 않는다**.
- 3점: `tip_px` = 혀끝 가장 앞점, `alveolar_px` = 윗앞니 바로 뒤 잇몸 융기(치조), `root_px` = 혀뿌리(움직이지 않을 기준점, 혀 뒤쪽 아래).
- `L_tongue.png`: 혀만, 가장자리 1.5px 부드러운 알파.
- `L_cavity.png`: 혀 자리를 **혀 아래 구강 픽셀 평균의 55% 밝기**로 메움(스크립트 자동). 손으로 칠하지 않는다.
- 검토: `F1_overlay.png`에서 초록 윤곽이 혀 가장자리와 ±3px 안에서 맞아야 함. 어긋나면 좌표 수정(cut 전이면 횟수 무관). `cut` 후 결과가 지저분하면 수정 1회.

## 7. Blender 2.5D 최소 구성 규칙

- 단위: 1px = 1mm(씬 단위 m, 스케일 0.001). 카메라 직교, `ortho_scale = 가로px × 0.001`, 렌더 해상도 = 프레임 크기.
- 레이어: `L_cavity` z=0, `L_tongue` z=0.002. 이번 실험에선 입술·턱 레이어 없음(F 범위).
- 셰이프키 `L_contact`: 각 정점의 가중치 = (뿌리→끝 정규화 위치)^2.2 × (중심선 거리 감쇠). 혀끝은 치조로 정확히, 뿌리는 0. 수정 1회 허용값: 지수 2.2→1.6(변형 더 넓게) 또는 세분 60→90.
- 머티리얼 이미시브(조명 영향 없음)라 그림 색이 그대로 나온다. 조명·재질 "개선" 금지(F 범위 밖).
- 렌더: EEVEE(또는 EEVEE Next), PNG, 정지 2장 + 왕복 10장. Cycles 금지.

## 8. 메모리 제한

- 동시 실행: 터미널 + Blender `-b` 1개. 브라우저·Epic·Xcode·UE·다른 Blender 종료 상태에서 실행.
- 단계 전후 `memory_pressure | tail -1`. 여유 ≥30% 초록(진행) / 15~30% 노랑(STOP·보고) / <15% 빨강(즉시 STOP). 사용자 Activity Monitor 색이 있으면 그것이 우선.
- 디스크: 시작 전 `df -h /` 여유 ≥ 10GB(전 프레임 PNG 720p 수백 장 ≈ 수백 MB).
- 텍스처 최대 1280×720(원본). 세분 61×61(약 7천 면). 이 범위를 넘기지 않는다.

## 9. PASS / FAIL 기준 (revision 3 §10 그대로)

PASS = 다음 전부:
- (a) **사용자** 블라인드 판정: `F2_contact.png`와 왕복 영상이 "자연스럽다/쓸 만하다"
- (b) `F2_log.txt`의 혀끝→치조 거리 **≤ 5px**
- (c) 왕복 10장에서 혀 윤곽 찢어짐·겹침·구멍 없음(Codex가 이미지 확인)
- (d) 메모리 압력 초록~노랑 유지(빨강 발생 시 FAIL)

FAIL = 위 중 하나라도 아님. 처리: one-adjustment 1회(§7 허용값) → F-2 재실행 → 재판정. 두 번째 FAIL → "FALLBACK A 제안"으로 보고하고 STOP.
PASS → 보고하고 STOP. 다음(C1 유료 그림 세트)은 사용자 승인 후 Claude가 별도 지침 작성.

## 10. 첫 STOP 지점

**STOP F-0**: 3-1 실행 직후. `F0_contact_sheet.png`(파티에 이미지로), `F0_top_frames.json` 내용, Codex 추천 프레임 1장 + 이유, 메모리 압력. 사용자가 프레임을 확정하기 전에는 3-2를 실행하지 않는다.

## 11. Codex 보고 형식 (각 STOP, 파티와 `REPORT_Fn.md` 동일 내용)

```
[단계] F-0 / F-1 / F-2
[결과] PASS / FAIL / 질문
[증거] 생성 파일 목록(ls -l 출력 그대로) + 핵심 수치(선명도 상위 8 / 좌표 / 거리 px)
[이미지] 파티에 올린 이미지 파일명
[메모리] memory_pressure 여유 % 와 색(초록/노랑/빨강)
[문제] 한 줄(없으면 "없음")
[수정 횟수] 0 / 1
[하지 않은 것] 이번 단계에서 의도적으로 실행하지 않은 명령(예: "F-1 미실행 — 승인 대기")
[다음] "사용자 승인 대기"
```

---

[Codex 권장 모델]
Codex의 기본 코딩 모델(GPT-5 Codex 계열)이면 충분하다. 이 실험은 정해진 명령 실행·파일 확인·좌표 작성이라 상위 추론 모델이 필요 없다. 이미지 판독(프레임 추천, 혀 윤곽 좌표)이 있으므로 **이미지 입력이 되는 모델**이어야 한다.

[추론 레벨]
**medium.** F-0·F-2는 low로도 되지만 F-1(혀 윤곽 좌표 작성·오버레이 자체 검토)에서 medium이 필요하다. high는 쓰지 않는다(비용 대비 이득 없음). 자연스러움 판정(PASS (a))은 모델이 아니라 사용자가 한다.

여기까지 지침 작성. STOP. F 실행은 Codex가, 승인은 사용자가.
