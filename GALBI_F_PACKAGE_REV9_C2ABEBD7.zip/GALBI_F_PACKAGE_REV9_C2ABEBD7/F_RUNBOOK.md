# F 최소 실험 실행 절차 (비용 0 · revision 3 §10 [첫 최소 실험] 그대로)

Source of Truth: 이 ZIP(GALBI_F_PACKAGE_REV9_C2ABEBD7.zip) 내부 파일. Codex 실행은 `CODEX_F_INSTRUCTIONS.md`가 우선이고, 이 문서는 같은 F를 사람이 읽기 쉽게 풀어 쓴 것. 새 범위 없음.

금지(이번 실험 동안): 유료 생성 전부(Flow·Nano Banana·GPT Image) · UE/MetaHuman 재개 · 기존 저품질 Blender 머리/구강 메시 사용 · C′ 대규모 구현 · 기존 마스터 수정(읽기만). 메모리 압력이 **노랑 이상**이면 그 자리에서 STOP하고 보고.

## 준비 (5분)
```bash
mkdir -p "$HOME/Documents/Codex/KOREAN_PRONUNCIATION_SHORTS/GALBI_PILOT/09_F_EXPERIMENT"
cd "$HOME/Documents/Codex/KOREAN_PRONUNCIATION_SHORTS/GALBI_PILOT/09_F_EXPERIMENT"
# ZIP(GALBI_F_PACKAGE_REV9_C2ABEBD7.zip)을 이 폴더에 풀고 `shasum -a 256 -c MANIFEST_SHA256.txt` 로 검증
python3 -c "import PIL, numpy, matplotlib; print('ok')" || python3 -m pip install --user pillow numpy matplotlib
ffmpeg -version | head -1 && blender --version | head -1
```
Blender가 PATH에 없으면 `/Applications/Blender.app/Contents/MacOS/Blender` 를 대신 쓴다.
원본 `FLOW_TESTS/GALBI_NEUTRAL_CUTAWAY_V1/FLOW_GALBI_NEUTRAL_CUTAWAY_V1_720p.mp4` 는 **읽기만** 한다(복사·수정 없음).

## F-0 프레임 추출 + 선명도 상위 8장 (10분)
```bash
python3 F0_extract_frames.py "../../FLOW_TESTS/GALBI_NEUTRAL_CUTAWAY_V1/FLOW_GALBI_NEUTRAL_CUTAWAY_V1_720p.mp4" F_out
open F_out/F0_contact_sheet.png
```
**중단 F-0 — 여기서 STOP하고 보고**: `F0_contact_sheet.png`(이미지로 파티에 올림) + `F0_top_frames.json` 내용 + 사용자가 고른 프레임 파일명 1개 + 메모리 압력 색.
사용자 승인(프레임 확정) 후에만 F-1로.

## F-1 혀 윤곽 따기 + 레이어 3장 (40분)
```bash
python3 F1_trace_and_cut.py trace F_out/frames/<고른프레임>.png F_out     # 창에서 혀 윤곽 클릭 → Enter → 혀끝·치조·혀뿌리 3점 클릭 → Enter
python3 F1_trace_and_cut.py cut   F_out/frames/<고른프레임>.png F_out
open F_out/F1_layers_sheet.png
```
**중단 F-1 — STOP하고 보고**: `F1_layers_sheet.png` + `F1_trace.json`의 점 수와 tip/alveolar/root 좌표 + 메모리 색. 혀 분리가 지저분하면 trace를 **1회** 다시(one-adjustment).

## F-2 Blender 2.5D 최소 구성 + 렌더 (30분 + 렌더 수 분)
```bash
blender -b -P F2_blender_min25d.py -- "$PWD/F_out"
open F_out/render/F2_neutral.png F_out/render/F2_contact.png
```
(GUI로 보고 싶으면 `F_out/F2_scene.blend`를 열면 된다. 렌더 전 활동 모니터에서 메모리 압력 확인.)
**중단 F-2 — STOP하고 보고(최종)**:
- 증거: `F2_neutral.png`, `F2_contact.png`, `pingpong_0000~0009.png`(또는 ffmpeg로 합친 1초 mp4), 터미널의 "혀끝→치조 거리 N px"
- PASS: (a) 사용자 블라인드 판정 "자연스럽다/쓸 만하다" (b) 거리 ≤ 5px (c) 왕복에서 혀 윤곽 찢어짐·겹침 없음 (d) 메모리 압력 초록~노랑
- FAIL: "고무 같다/이상하다" 또는 윤곽 파손 또는 메모리 빨강 → one-adjustment 1회(F2 스크립트의 `wgt = t ** 2.2`를 `t ** 1.6`으로 바꿔 변형을 더 넓게 퍼뜨림, 또는 subdiv 60→90) → 재판정 1회. 두 번째 FAIL → FALLBACK A 제안.
- PASS여도 **여기서 STOP**. C1(유료 그림 세트)은 별도 승인 후.

## 보고 형식
```
[단계] F-0 / F-1 / F-2
[결과] PASS / FAIL / 질문
[증거] 파일명·수치·캡처
[메모리] 초록/노랑/빨강
[문제] 한 줄
[수정 횟수] 0 / 1
[다음] 사용자 승인 대기
```
