# F1_trace_and_cut.py — 고른 프레임에서 혀 윤곽을 클릭으로 따고(trace), 레이어 3장을 만든다. (비용 0)
# 사용 1) 따기:  python3 F1_trace_and_cut.py trace <frame.png> <출력폴더>
#        창이 뜨면 혀 윤곽을 시계 방향으로 12~30번 클릭 → Enter 로 저장. 그다음 혀끝(1점), 치조=윗앞니 뒤 잇몸(1점), 혀뿌리 고정점(1점)을 차례로 클릭 → Enter.
# 사용 2) 자르기: python3 F1_trace_and_cut.py cut <frame.png> <출력폴더>
# 필요: python3 + Pillow + numpy + matplotlib (없으면 `python3 -m pip install pillow numpy matplotlib`)
import sys, os, json
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

mode, frame, out = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(out, exist_ok=True)
meta_path = os.path.join(out, "F1_trace.json")

if mode == "trace":
    import matplotlib; matplotlib.use("MacOSX") if sys.platform == "darwin" else None
    import matplotlib.pyplot as plt
    im = Image.open(frame).convert("RGB")
    plt.figure(figsize=(12, 7)); plt.imshow(im); plt.title("1/2  혀 윤곽을 시계 방향으로 클릭 (12~30점) → Enter"); plt.axis("off")
    poly = plt.ginput(n=-1, timeout=0)
    plt.title("2/2  혀끝 → 치조(윗앞니 뒤 잇몸) → 혀뿌리 고정점 순서로 3점 클릭 → Enter")
    pts = plt.ginput(n=3, timeout=0); plt.close()
    if len(poly) < 6 or len(pts) != 3: sys.exit("점이 부족합니다. 다시 실행하세요.")
    meta = {"frame": os.path.basename(frame), "size": im.size, "tongue_polygon": [[round(x), round(y)] for x, y in poly],
            "tip_px": [round(pts[0][0]), round(pts[0][1])], "alveolar_px": [round(pts[1][0]), round(pts[1][1])], "root_px": [round(pts[2][0]), round(pts[2][1])]}
    json.dump(meta, open(meta_path, "w"), indent=1); print("저장:", meta_path); print(json.dumps(meta, ensure_ascii=False))
    print("\n[중단 F-1a] F1_trace.json 의 점 수와 tip/alveolar/root 픽셀 좌표를 보고.")

elif mode == "cut":
    meta = json.load(open(meta_path)); im = Image.open(frame).convert("RGBA"); w, h = im.size
    poly = [tuple(p) for p in meta["tongue_polygon"]]
    # 혀 마스크 (가장자리 2px 부드럽게)
    mask = Image.new("L", (w, h), 0); ImageDraw.Draw(mask).polygon(poly, fill=255)
    mask_soft = mask.filter(ImageFilter.GaussianBlur(1.5))
    # L_tongue: 혀만, 알파 = 마스크
    tongue = im.copy(); tongue.putalpha(mask_soft); tongue.save(os.path.join(out, "L_tongue.png"))
    # L_cavity: 혀 자리를 어두운 구강색으로 메운 배경판 (혀가 움직여도 뒤가 비지 않게). 색은 혀 아래쪽 구강 픽셀 평균을 어둡게.
    arr = np.asarray(im.convert("RGB"), dtype=np.float32); m = np.asarray(mask) > 127
    ys, xs = np.where(m); band = arr[max(ys.max()-10, 0):min(ys.max()+10, h), xs.min():xs.max()]
    base = band.reshape(-1, 3).mean(axis=0) * 0.55                      # 55% 밝기 = 입 안 그늘
    cavity = arr.copy(); cavity[m] = base
    cav_im = Image.fromarray(cavity.astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.8))
    # 혀 영역만 블러된 걸 쓰고 나머지는 원본 유지
    cav_final = Image.composite(cav_im, im.convert("RGB"), mask.filter(ImageFilter.MaxFilter(5)))
    cav_final.save(os.path.join(out, "L_cavity.png"))
    # L_rest: 혀를 뺀 나머지(입술·이·입천장 등). F 에서는 L_cavity 를 배경으로 쓰므로 참고용.
    rest = im.copy(); inv = Image.eval(mask_soft, lambda v: 255 - v); rest.putalpha(inv); rest.save(os.path.join(out, "L_rest.png"))
    # 썸네일 비교표
    sheet = Image.new("RGB", (w * 3 // 2, h // 2), (20, 20, 20))
    for i, name in enumerate(["L_cavity.png", "L_tongue.png", "L_rest.png"]):
        t = Image.open(os.path.join(out, name)).convert("RGBA"); bg = Image.new("RGBA", t.size, (60, 60, 60, 255)); bg.alpha_composite(t)
        sheet.paste(bg.convert("RGB").resize((w // 2, h // 2)), (i * w // 2, 0))
    sheet.save(os.path.join(out, "F1_layers_sheet.png"))
    print("저장: L_tongue.png / L_cavity.png / L_rest.png / F1_layers_sheet.png")
    print("\n[중단 F-1b] F1_layers_sheet.png 보고: 혀가 깨끗이 분리됐는가, 구강 배경판에 이상한 자국이 없는가.")
elif mode == "overlay":
    # Codex 가 F1_trace.json 을 직접 써 넣은 경우(클릭 없이): 다각형·3점을 프레임 위에 그려 검토용 이미지를 만든다
    meta = json.load(open(meta_path)); im = Image.open(frame).convert("RGB"); d = ImageDraw.Draw(im)
    poly = [tuple(p) for p in meta["tongue_polygon"]]; d.polygon(poly, outline=(0, 255, 0)); d.line(poly + [poly[0]], fill=(0, 255, 0), width=2)
    for key, col in (("tip_px", (255, 0, 0)), ("alveolar_px", (0, 128, 255)), ("root_px", (255, 200, 0))):
        x, y = meta[key]; d.ellipse((x - 6, y - 6, x + 6, y + 6), outline=col, width=3); d.text((x + 8, y - 8), key.replace("_px", ""), fill=col)
    im.save(os.path.join(out, "F1_overlay.png")); print("저장:", os.path.join(out, "F1_overlay.png"))
    print("\n[검토] F1_overlay.png 에서 초록 윤곽이 혀 가장자리와 맞는지, 빨강=혀끝, 파랑=치조(윗앞니 바로 뒤 잇몸), 노랑=혀뿌리인지 확인.")
else:
    sys.exit("mode 는 trace / overlay / cut")
