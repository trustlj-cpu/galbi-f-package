# F2_blender_min25d.py — F 최소 실험: 배경판 + 혀 레이어 2.5D 변형(셰이프키 자동 생성) + 정지 2장 + 10프레임 왕복 렌더. (비용 0)
# 실행: Blender 를 새 파일로 열고 텍스트 편집기에 붙여 넣은 뒤, 아래 LAYERS 폴더 경로만 고치고 Run Script.
#      또는 터미널: blender -b -P F2_blender_min25d.py -- /절대경로/F_out
# 입력: F1 출력 폴더(L_cavity.png, L_tongue.png, F1_trace.json)
# 출력: F_out/render/F2_neutral.png, F2_contact.png, pingpong_####.png, F2_scene.blend
import bpy, json, os, sys, math, mathutils

argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
LAYERS = argv[0] if argv else "/ABSOLUTE/PATH/TO/F_out"          # ← 수정
meta = json.load(open(os.path.join(LAYERS, "F1_trace.json")))
W, H = meta["size"]; S = 1.0 / 1000.0                                # 1px = 1mm 로 둔다
def px2xy(p): return ((p[0] - W / 2) * S, (H / 2 - p[1]) * S)
tip, alv, root = map(px2xy, (meta["tip_px"], meta["alveolar_px"], meta["root_px"]))

sc = bpy.context.scene
for ob in list(bpy.data.objects): bpy.data.objects.remove(ob, do_unlink=True)
sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in [i.identifier for i in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items] else "BLENDER_EEVEE"
sc.render.resolution_x, sc.render.resolution_y = W, H; sc.render.resolution_percentage = 100
sc.render.film_transparent = False; sc.render.image_settings.file_format = "PNG"
OUT = os.path.join(LAYERS, "render"); os.makedirs(OUT, exist_ok=True)

def plane(name, img, z, subdiv=0):
    bpy.ops.mesh.primitive_plane_add(size=1); ob = bpy.context.object; ob.name = name
    ob.scale = (W * S, H * S, 1); ob.location.z = z
    bpy.ops.object.transform_apply(scale=True)
    if subdiv:
        bpy.ops.object.mode_set(mode="EDIT"); bpy.ops.mesh.select_all(action="SELECT"); bpy.ops.mesh.subdivide(number_cuts=subdiv); bpy.ops.object.mode_set(mode="OBJECT")
    mat = bpy.data.materials.new(name); mat.use_nodes = True
    if hasattr(mat, "blend_method"): mat.blend_method = "BLEND"
    nt = mat.node_tree; tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = bpy.data.images.load(os.path.join(LAYERS, img)); tex.interpolation = "Cubic"
    bsdf = nt.nodes["Principled BSDF"]; nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"]); nt.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    bsdf.inputs["Roughness"].default_value = 1.0; bsdf.inputs["Specular IOR Level"].default_value = 0.0 if "Specular IOR Level" in bsdf.inputs else None
    ob.data.materials.append(mat); return ob

cav = plane("L_cavity", "L_cavity.png", 0.0)
tongue = plane("L_tongue", "L_tongue.png", 0.002, subdiv=60)     # 61x61 격자, 약 7천 면 — 8GB 에서 가벼움

# 셰이프키 L_contact 자동 생성: 혀끝을 치조로 옮기고, 뿌리 쪽으로 갈수록 영향이 줄어드는 부드러운 변형(끝 올림 + 약간 앞으로)
tongue.shape_key_add(name="Basis"); sk = tongue.shape_key_add(name="L_contact")
tipv, alvv, rootv = (mathutils.Vector((x, y, 0)) for x, y in (tip, alv, root))
delta = alvv - tipv                                   # 혀끝이 가야 할 변위
L = (tipv - rootv).length
for i, v in enumerate(tongue.data.vertices):
    p = mathutils.Vector((v.co.x, v.co.y, 0))
    t = ((p - rootv).dot((tipv - rootv).normalized()) / L) if L > 0 else 0   # 뿌리 0 → 끝 1
    t = max(0.0, min(1.0, t)); wgt = t ** 2.2                                   # 끝쪽에 변형 집중
    side = abs((p - rootv).cross((tipv - rootv).normalized()).z) / max(L, 1e-6) # 중심선에서 멀면 덜 움직임
    wgt *= max(0.0, 1.0 - 1.4 * side)
    sk.data[i].co = v.co + delta * wgt

# 혀끝 고정 확인용 엠프티
alv_e = bpy.data.objects.new("ALV_POINT", None); sc.collection.objects.link(alv_e); alv_e.location = (alv[0], alv[1], 0.003); alv_e.empty_display_size = 0.004

# 카메라(직교, 화면 꽉 채움) + 조명 없이 이미시브 느낌: 월드 밝기
cam_d = bpy.data.cameras.new("Cam"); cam_d.type = "ORTHO"; cam_d.ortho_scale = W * S
cam = bpy.data.objects.new("Cam", cam_d); sc.collection.objects.link(cam); cam.location = (0, 0, 1.0); sc.camera = cam
sc.world = sc.world or bpy.data.worlds.new("W"); sc.world.use_nodes = True
bg = sc.world.node_tree.nodes["Background"]; bg.inputs[0].default_value = (1, 1, 1, 1); bg.inputs[1].default_value = 1.0
for m in bpy.data.materials:   # 그림을 그대로 보이게: 머티리얼을 이미시브로 전환
    bsdf = m.node_tree.nodes["Principled BSDF"]; tex = [n for n in m.node_tree.nodes if n.type == "TEX_IMAGE"][0]
    m.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Emission Color"]); bsdf.inputs["Emission Strength"].default_value = 1.0; bsdf.inputs["Base Color"].default_value = (0, 0, 0, 1)

def render(path):
    sc.render.filepath = path; bpy.ops.render.render(write_still=True); print("렌더:", path)

kb = tongue.data.shape_keys.key_blocks["L_contact"]
kb.value = 0.0; render(os.path.join(OUT, "F2_neutral.png"))
kb.value = 1.0; render(os.path.join(OUT, "F2_contact.png"))
# 10프레임 왕복 (0→1→0)
for f in range(10):
    kb.value = math.sin(math.pi * f / 9) ; render(os.path.join(OUT, f"pingpong_{f:04d}.png"))
kb.value = 0.0
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(LAYERS, "F2_scene.blend"))
# 혀끝 도달 거리(px) 계산: 셰이프키 1.0 에서 혀끝 정점(기준 tip 에 가장 가까운 정점)의 위치
tip_idx = min(range(len(tongue.data.vertices)), key=lambda i: (mathutils.Vector((tongue.data.vertices[i].co.x, tongue.data.vertices[i].co.y)) - mathutils.Vector(tip)).length)
moved = sk.data[tip_idx].co; dist_px = (mathutils.Vector((moved.x, moved.y)) - mathutils.Vector(alv)).length / S
print(f"혀끝→치조 거리(접촉 포즈): {dist_px:.1f}px  (PASS 기준 5px 이내)")
print("\n[중단 F-2] F2_neutral.png / F2_contact.png / pingpong_0000~0009.png 를 보고. 사용자 블라인드 판정 + 거리 px + 윤곽 파손 여부 + 메모리 압력 색 보고. 여기서 STOP.")
